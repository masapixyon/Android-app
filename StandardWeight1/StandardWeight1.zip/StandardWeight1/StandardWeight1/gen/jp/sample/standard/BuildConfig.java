/** Automatically generated file. DO NOT MODIFY */
package jp.sample.standard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
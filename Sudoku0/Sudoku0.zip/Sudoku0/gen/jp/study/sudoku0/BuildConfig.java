/** Automatically generated file. DO NOT MODIFY */
package jp.study.sudoku0;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
/** Automatically generated file. DO NOT MODIFY */
package samle.aplication.memopad;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}